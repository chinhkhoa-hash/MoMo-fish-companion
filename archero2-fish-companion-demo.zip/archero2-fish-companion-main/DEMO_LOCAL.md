# Chạy demo local cho stakeholder

## 1. Yêu cầu môi trường
- Node.js >= 18 (khuyến nghị 20)
- npm (đi kèm Node.js)

## 2. Cài đặt & chạy (chế độ dev - khuyến nghị cho demo)
```bash
npm install
npm run dev
```
Sau đó mở trình duyệt tại:
```
http://localhost:3000/archero2-fish-companion
```
(App có cấu hình `basePath: "/archero2-fish-companion"` để deploy lên GitHub Pages, nên khi chạy local vẫn cần path này.)

## 3. Build bản production tĩnh (tùy chọn, để demo giống bản deploy thật)
```bash
npm run build
npx serve out -l 4000
```
Rồi mở:
```
http://localhost:4000/archero2-fish-companion
```

## 4. Những gì demo cho stakeholder
- **Fish Tracker theo hồ (Lake)**: chọn 1 trong 4 hồ (Lakehouse, Sunset, Oceanic, Polar), mỗi hồ có pool cá với tỉ lệ hiếm cố định (SR/MR/LR/SE/LE/LEG).
- **Bắt cá (Catch Fish)**: bấm từng loại cá để trừ dần khỏi pool, có Undo và "Catch Whole Pool" để demo nhanh khi hết pool.
- **Xác suất cá Legendary tiếp theo**: tính động dựa trên số cá còn lại trong pool, có màu xanh/đỏ báo hiệu tỉ lệ đang cao/thấp hơn baseline.
- **Refill Lake**: làm mới pool khi đã bắt hết.
- **Broken Lines counter** (0/120): theo dõi số lần đứt dây câu.
- **Thống kê tổng**: tổng số cá đã bắt & tổng cá Legendary đã bắt, chi tiết theo từng hồ (hover card).
- **Quest Tracker** (icon góc trái): theo dõi tiến độ các nhiệm vụ trong game (Silver Tickets, Daily Login, Gold Cave, Kill Minions...) và số phần thưởng còn lại.
- **Fish Set selector**: đổi bộ ảnh cá (Set 1/2/3) tùy theo skin đang có trong game.
- **Reset All**: xóa toàn bộ dữ liệu đã lưu (có bước xác nhận).
- Dữ liệu được lưu vào `localStorage` của trình duyệt — demo xong vẫn giữ trạng thái nếu refresh lại trang.

## 5. Lưu ý kỹ thuật đã điều chỉnh để chạy offline/local ổn định
- Đã thay Google Fonts (Geist/Geist Mono) bằng system font stack, tránh phụ thuộc mạng khi build — không ảnh hưởng giao diện đáng kể.
